package com.example.gorshok_ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import com.example.gorshok_ai.ml.Gmodel
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer

class MainActivity : AppCompatActivity() {

    lateinit var selectBtn: Button
    lateinit var predBtn: Button
    lateinit var takeBtn: Button
    lateinit var resView: TextView
    lateinit var imageView: ImageView
    lateinit var bitmap: Bitmap


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        getPermission()

        selectBtn=findViewById(R.id.selectBtn)
        takeBtn=findViewById(R.id.takeBtn)
        predBtn=findViewById(R.id.predictBtn)
        resView=findViewById(R.id.resView)
        imageView=findViewById(R.id.imageView)

        val labels=application.assets.open("labels.txt").bufferedReader().readLines()

        //image processor
        val imageProcessor= ImageProcessor.Builder()
            .add(NormalizeOp(0.0f,255.0f))
            .add(ResizeOp(224,224,ResizeOp.ResizeMethod.BILINEAR))
            .build()

        selectBtn.setOnClickListener{
            val intent= Intent()
            intent.setAction(Intent.ACTION_GET_CONTENT)
            intent.setType("image/*")
            startActivityForResult(intent,100)
        }
        takeBtn.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intent, 200)
        }
        predBtn.setOnClickListener{

            var tensorImage= TensorImage(DataType.FLOAT32)
            tensorImage.load(bitmap)

            tensorImage= imageProcessor.process(tensorImage)

            val model = Gmodel.newInstance(this)

            // Creates inputs for reference.
            val inputFeature0 = TensorBuffer.createFixedSize(intArrayOf(1, 224, 224, 3), DataType.FLOAT32)
            inputFeature0.loadBuffer(tensorImage.buffer)

            // Runs model inference and gets result.
            val outputs = model.process(inputFeature0)
            val outputFeature0 = outputs.outputFeature0AsTensorBuffer
            var res = ""

            //var maxIdx=0
            outputFeature0.floatArray.forEachIndexed{index,fl->
                res += labels[index] + " "+ (outputFeature0.floatArray[index]*100).toString() +"%\n"
            }
            resView.text = res

            // Releases model resources if no longer used.
            model.close()}
    }

    fun getPermission() {
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 11)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode==11){
            if (grantResults.size>0){
                if (grantResults[0]!=PackageManager.PERMISSION_GRANTED){
                    this.getPermission()
                }
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?)
    {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==100){
            val uri=data?.data
            bitmap= MediaStore.Images.Media.getBitmap(this.contentResolver,uri)
            imageView.setImageBitmap(bitmap)
        }
        else if(requestCode==200){
            bitmap = data?.extras?.get("data") as Bitmap
            imageView.setImageBitmap(bitmap)
        }
    }
}
